//: UIKit Playground

import UIKit
import XCPlayground

<#code#>


//XCPlaygroundPage.currentPage.needsIndefiniteExecution = true
//XCPlaygroundPage.currentPage.liveView = <#live view#>